﻿namespace Interfaces
{
    public interface IMovable
    {
        int FacingDirection { get; }
    }
}