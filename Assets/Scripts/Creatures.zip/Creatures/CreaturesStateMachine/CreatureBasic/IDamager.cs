﻿namespace Creatures.CreaturesStateMachine.CreatureBasic
{
    public interface IDamager
    {
        void Attack();
    }
}