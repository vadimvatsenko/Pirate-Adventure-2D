﻿using UnityEngine;

namespace Creatures.CreaturesStateMachine.Hero
{
    public class HeroDoubleJumpState : HeroAiredState
    {
        public HeroDoubleJumpState(Hero hr, CreatureStateMachine stateMachine, int animBoolName) 
            : base(hr, stateMachine, animBoolName)
        {
        }

        public override void Enter()
        {
            base.Enter();
            
            Rb2D.velocity = new Vector2(Rb2D.velocity.x, Hr.DoubleJumpForce);
        }

        public override void Update()
        {
            base.Update();
            
            if (Rb2D.velocity.y < 0)
            {
                StateMachine.ChangeState(Hr.FallState);
            }
        }

        public override void Exit()
        {
            base.Exit();
        }
    }
}