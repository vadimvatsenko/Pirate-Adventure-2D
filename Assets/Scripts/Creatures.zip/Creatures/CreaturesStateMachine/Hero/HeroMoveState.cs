﻿using UnityEngine;

namespace Creatures.CreaturesStateMachine.Hero
{
    public class HeroMoveState : HeroGroundState
    {
        
        public HeroMoveState(Hero hr, CreatureStateMachine stateMachine, int animBoolName) 
            : base(hr, stateMachine, animBoolName)
        {
        }

        public override void Enter()
        {
            base.Enter();
            Rb2D.velocity = new Vector2(Hr.XInput * Hr.MovementSpeed, Rb2D.velocity.y);
        }

        public override void Update()
        {
            base.Update();
            
            if (Hr.XInput == 0)
            {
                StateMachine.ChangeState(Hr.IdleState);
            }
            Rb2D.velocity = new Vector2(Hr.XInput * Hr.MovementSpeed, Hr.Rb2D.velocity.y);
        }

        public override void Exit()
        {
            base.Exit();
        }
    }
}