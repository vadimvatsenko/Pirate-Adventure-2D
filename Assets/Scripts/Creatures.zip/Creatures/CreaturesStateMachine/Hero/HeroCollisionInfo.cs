﻿namespace Creatures.CreaturesStateMachine.Hero
{
    public class HeroCollisionInfo : CreatureCollisionInfo
    {
        
    }
}